from setuptools import setup

setup(
    name='addrext',
    version='0.1',
    description='Address Extractor',
    url='https://github.com/hydraseq/addrext',
    author='Efrain Olivares',
    author_email='efrain.olivares@gmail.com',
    license='MIT',
    packages=[],
    zip_safe=False
    )
